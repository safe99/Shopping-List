package com.example.arsal.shoppinglist;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    TabHost tabHost;
    ListView lists,lists2;
    LinearLayout remove,parent;
    ImageButton addList;
    Button load;
    TextView text_new;
    ArrayList<ArrayList<Product>> storeLists;
    ArrayList<String> storeNameLists;
    FragmentManager fragmentManager = getSupportFragmentManager();
    NewFragment over = new NewFragment();
    boolean open = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        remove = (LinearLayout)(findViewById(R.id.layout_new));
        parent = (LinearLayout)(findViewById(R.id.tab1));
        addList = (ImageButton)(findViewById(R.id.imageButton_new));
        text_new = (TextView)(findViewById(R.id.textView_new));
        load = (Button)(findViewById(R.id.button_load));

        addList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == addList.getId()){
                    addList.setVisibility(View.GONE);
                    text_new.setVisibility(View.GONE);

                    if (open == false) {
                        getSupportFragmentManager().beginTransaction().add(R.id.layout_new, over, "first").commit();
                        open = true;
                    }
                    else fragmentManager.beginTransaction().setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out).show(over).commit();
                }
            }
        });

        lists = (ListView)(findViewById(R.id.listView_id));
        lists2 = (ListView) (findViewById(R.id.listView_id2));
        lists2.setVisibility(View.GONE);
        storeLists = new ArrayList<>();
        storeNameLists = new ArrayList<>();

        CustomAdapter myAdapter = new CustomAdapter(this,R.layout.layout_listviewer_main,storeLists,storeNameLists);
        lists.setAdapter(myAdapter);
        lists.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i){
                    default:
                        lists.setVisibility(View.GONE);
                        CustomAdapter2 myAdapter2 = new CustomAdapter2(getBaseContext(), R.layout.layout_listviewer, storeLists.get(i));
                        lists2.setAdapter(myAdapter2);
                        lists2.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });

        lists2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                lists2.setVisibility(View.GONE);
                CustomAdapter myAdapter = new CustomAdapter(getBaseContext(),R.layout.layout_listviewer_main,storeLists,storeNameLists);
                lists.setAdapter(myAdapter);
                lists.setVisibility(View.VISIBLE);

            }
        });

        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.button_load){
                    Log.d("Eggus",loadData().toString());
                    Log.d("Eggus2",loadDataName().toString());
                    storeLists = loadData();
                    storeNameLists = loadDataName();
                    CustomAdapter myAdapter = new CustomAdapter(getBaseContext(), R.layout.layout_listviewer_main, storeLists, storeNameLists);
                    lists.setAdapter(myAdapter);
                    lists.setVisibility(View.VISIBLE);
                    lists2.setVisibility(View.GONE);
                }
            }
        });


        tabHost = (TabHost)(findViewById(R.id.tabHost_id));
        tabHost.setup();

        //Tab 1 - Shopping
        TabHost.TabSpec spec = tabHost.newTabSpec("Tab One"); //Tab ID kinda
        spec.setContent(R.id.tab1);
        spec.setIndicator("New List");
        tabHost.addTab(spec);

        //Tab 2 - Location
        spec = tabHost.newTabSpec("Tab Two");
        spec.setContent(R.id.tab2);
        spec.setIndicator("My Lists"); //Tab Name
        tabHost.addTab(spec);

        //Tab 3 - Deals
        spec = tabHost.newTabSpec("Tab Three");
        spec.setContent(R.id.tab3);
        spec.setIndicator("Saved Items");
        tabHost.addTab(spec);
    }

    public class CustomAdapter extends ArrayAdapter<ArrayList<Product>> {
        ArrayList<ArrayList<Product>> list;
        ArrayList<String> names;
        Context mainContext;

        public CustomAdapter(Context context, int resource, ArrayList<ArrayList<Product>> objects, ArrayList<String> names2) {
            super(context, resource, objects);
            mainContext = context;
            list=objects;
            names = names2;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater)mainContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            View layoutView = inflater.inflate(R.layout.layout_listviewer_main,null);
            TextView textView = (TextView)layoutView.findViewById(R.id.textView_listName);
            ImageView imageView = (ImageView)layoutView.findViewById(R.id.imageView_listImage);
            ImageView removeList = (ImageView)layoutView.findViewById(R.id.imageButton_remove_main);

            try {
                textView.setText(names.get(position));
            }catch(IndexOutOfBoundsException e){
                textView.setText("Error");
            }

            switch(position){
                default: imageView.setImageResource(R.drawable.cart); //Change this
            }

            removeList.setImageResource(R.drawable.delete3);

            removeList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(v.getId() == R.id.imageButton_remove){
                        storeLists.remove(list.get(position));
                        notifyDataSetChanged();
                    }
                }
            });

            return layoutView;
        }
    }

    public class CustomAdapter2 extends ArrayAdapter<Product> {
        ArrayList<Product> lista;
        Context mainContext;

        public CustomAdapter2(Context context, int resource, ArrayList<Product> objects) {
            super(context, resource, objects);
            mainContext = context;
            lista = objects;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater)mainContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            View layoutView = inflater.inflate(R.layout.layout_listviewer,null);
            TextView tv_name = (TextView)layoutView.findViewById(R.id.textView_listName);
            TextView tv_quant = (TextView)layoutView.findViewById(R.id.textView_listQuantity);
            TextView tv_unit = (TextView)layoutView.findViewById(R.id.textView_listUnits);
            TextView tv_aisle = (TextView)layoutView.findViewById(R.id.textView_listAisleName);
            TextView tv_aisleNum = (TextView)layoutView.findViewById(R.id.textView_listAisleNum);
            TextView tv_priority = (TextView)layoutView.findViewById(R.id.textView_listPriority);
            TextView tv_calories = (TextView)layoutView.findViewById(R.id.textView_listCalories);
            TextView tv_price = (TextView)layoutView.findViewById(R.id.textView_listPrice);
            ImageView imageView = (ImageView)layoutView.findViewById(R.id.imageView_listImage);
            ImageButton removeFromList = (ImageButton)layoutView.findViewById(R.id.imageButton_remove);

            tv_name.setText(lista.get(position).getName());

            if(Integer.parseInt(lista.get(position).getQuantity().toString()) != 1)
                tv_quant.setText(lista.get(position).getQuantity().toString());
            else tv_quant.setText("");

            if(lista.get(position).getUnit().toString().equals("Units"))
                tv_unit.setText("");
            else tv_unit.setText(lista.get(position).getUnit());

            if(lista.get(position).getAisleName().toString().equals("Aisle Name"))
                tv_aisle.setText("");
            else tv_aisle.setText(lista.get(position).getAisleName());

            if(Integer.parseInt(lista.get(position).getAisleNum().toString()) != 1)
                tv_aisleNum.setText(lista.get(position).getAisleNum().toString());
            else tv_aisleNum.setText("");

            tv_priority.setText(lista.get(position).getPriority().toString());

            if(Integer.parseInt(lista.get(position).getCalories().toString()) != 0)
                tv_calories.setText(lista.get(position).getCalories().toString()+" calories");
            else tv_calories.setText("");

            if(lista.get(position).getPrice() != 0.0)
                tv_price.setText("$"+String.valueOf(lista.get(position).getPrice()));
            else tv_price.setText("");

            switch(position){
                default: imageView.setImageBitmap(lista.get(position).getImage()); //Change this
            }

            removeFromList.setImageResource(R.drawable.delete3);

            removeFromList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(v.getId() == R.id.imageButton_remove){
                        lista.remove(lista.get(position));
                        notifyDataSetChanged();
                    }
                }
            });

            return layoutView;
        }
    }

    public void addNewList(ArrayList<Product> list3, String name) {
        ArrayList<Product> temp = new ArrayList<>();
        for (Product i : list3) {
            temp.add(i);
        }
        storeLists.add(temp);
        storeNameLists.add(name);
        CustomAdapter myAdapter = new CustomAdapter(this, R.layout.layout_listviewer_main, storeLists, storeNameLists);
        lists.setAdapter(myAdapter);

        saveData();
    }

    public void saveData(){
        try {
            FileOutputStream fileStream = openFileOutput("stores", Context.MODE_PRIVATE);
            ObjectOutputStream save = new ObjectOutputStream(fileStream);
            save.writeObject(storeLists);
            save.close();
            fileStream.close();

            FileOutputStream fileStream2 = openFileOutput("storeNames", Context.MODE_PRIVATE);
            ObjectOutputStream save2 = new ObjectOutputStream(fileStream2);
            save2.writeObject(storeNameLists);
            save2.close();
            fileStream2.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<ArrayList<Product>> loadData(){
        try {
            FileInputStream inputStream = openFileInput("stores");
            ObjectInputStream loadIt = new ObjectInputStream(inputStream);
            storeLists = (ArrayList<ArrayList<Product>>)loadIt.readObject();
            loadIt.close();
            inputStream.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return storeLists;
    }

    public ArrayList<String> loadDataName(){
        try {
            FileInputStream inputStream2 = openFileInput("storeNames");
            ObjectInputStream loadIt2 = new ObjectInputStream(inputStream2);
            storeNameLists = (ArrayList<String>)loadIt2.readObject();
            loadIt2.close();
            inputStream2.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return storeNameLists;
    }

    public void updateFragment(){
        fragmentManager.beginTransaction().setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out).hide(over).commit();
        addList.setVisibility(View.VISIBLE);
        text_new.setVisibility(View.VISIBLE);
    }

}
