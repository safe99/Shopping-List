package com.example.arsal.shoppinglist;

import android.graphics.Bitmap;

/**
 * Created by 10017284 on 5/12/2017.
 */

public class Product {

    private String name,unit,aisleName;
    private int quantity,aisleNum,priority,calories;
    private double price;
    private Bitmap image;

    public Product(String name, int quantity, String unit, int aisleNum, String aisleName, int priority, int calories, double price, Bitmap image){
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.aisleNum = aisleNum;
        this.aisleName = aisleName;
        this.priority = priority;
        this.calories = calories;
        this.price = price;
        this.image = image;
    }

    public String getName(){
        return name;
    }

    public Integer getQuantity(){
        return quantity;
    }

    public String getUnit(){
        return unit;
    }

    public Integer getAisleNum(){
        return aisleNum;
    }

    public String getAisleName(){
        return aisleName;
    }

    public Integer getPriority(){
        return priority;
    }

    public Integer getCalories(){
        return calories;
    }

    public double getPrice(){
        return price;
    }

    public Bitmap getImage(){return image;}

    public String toString(){
        return name;
    }

}
