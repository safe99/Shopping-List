package com.example.arsal.shoppinglist;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;


/**
 * Created by 10017284 on 5/2/2017.
 */

public class NewFragment extends Fragment{

    ArrayList<Integer> numbers,prior;
    Spinner quantity,aisle,priority;
    ListView listed;
    ArrayList<Product> items = new ArrayList<Product>();
    Button image,addition,complete;
    EditText name,units,aisleName,calories,price;

    String iName,iUnit,iAisleName;
    int iQuantity,iAisleNum,iPriority,iCalories;
    double iPrice;
    Bitmap retrievedImage;

    public NewFragment(){}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_new,container,false);
        listed = (ListView)view.findViewById(R.id.listView_items);
        final Bitmap milk = BitmapFactory.decodeResource(getContext().getResources(),
                R.drawable.milk);
        final Product sample = new Product("Milk",1,"Quarts",4,"Dairy",1,400,3.95,milk);
        items.add(sample);

        final CustomAdapter myAdapter2 = new CustomAdapter(getContext(),R.layout.layout_listviewer,items);
        listed.setAdapter(myAdapter2);

        quantity = (Spinner)view.findViewById(R.id.spinner);
        aisle = (Spinner)view.findViewById(R.id.spinner_aisle);
        priority = (Spinner)view.findViewById(R.id.spinner_priority);

        numbers = new ArrayList<>();
        prior = new ArrayList<>();

        for(int i=1;i<=30;i++){
            numbers.add(i);
            if (i < 10)
                prior.add(i);
        }

        ArrayAdapter spinning = new ArrayAdapter(getActivity(),R.layout.custom_spinner_dropdown_item,numbers);
        ArrayAdapter spinning2 = new ArrayAdapter(getActivity(),R.layout.custom_spinner_dropdown_item,prior);
        quantity.setAdapter(spinning);
        priority.setAdapter(spinning2);
        aisle.setAdapter(spinning);

        addition = (Button)view.findViewById(R.id.button_addition);
        image = (Button)view.findViewById(R.id.button_image);
        complete = (Button)view.findViewById(R.id.button_complete);
        name = (EditText)view.findViewById(R.id.editText_name);
        units = (EditText)view.findViewById(R.id.editText_units);
        aisleName = (EditText)view.findViewById(R.id.editText_aisle);
        calories = (EditText)view.findViewById(R.id.editText_calories);
        price = (EditText)view.findViewById(R.id.editText_price);

        addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.button_addition) {
                    Toast message_default = Toast.makeText(getContext(), "Please Enter An Item Name", Toast.LENGTH_SHORT);

                    if (name.getText().toString().length() < 1)
                        message_default.show();

                    else {
                        iName = name.getText().toString();
                        iQuantity = Integer.parseInt(quantity.getSelectedItem().toString());
                        iUnit = units.getText().toString();
                        iAisleNum = Integer.parseInt(aisle.getSelectedItem().toString());
                        iAisleName = aisleName.getText().toString();
                        iPriority = Integer.parseInt(priority.getSelectedItem().toString());

                        try{
                            iCalories = Integer.parseInt(calories.getText().toString());
                        }catch(NumberFormatException e){
                            iCalories = 0;
                        }

                        try{
                            iPrice = Double.parseDouble(price.getText().toString());
                        }catch(NumberFormatException e){
                            iPrice = 0.00;
                        }

                        items.add(new Product(iName, iQuantity, iUnit, iAisleNum, iAisleName, iPriority, iCalories, iPrice,milk));
                        CustomAdapter myAdapter2 = new CustomAdapter(getContext(), R.layout.layout_listviewer, items);
                        listed.setAdapter(myAdapter2);

                        Toast message_new = Toast.makeText(getContext(), "Item Added!", Toast.LENGTH_SHORT);
                        message_new.show();
                    }
                }
            }
        });

        complete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.button_complete){
                    final AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                    final View mView = ((MainActivity)(getActivity())).getLayoutInflater().inflate(R.layout.dialog_store,null);
                    final EditText store = (EditText)mView.findViewById(R.id.editText_storeName);
                    Button addStore = (Button)mView.findViewById(R.id.button_addStore);
                        addStore.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (!store.getText().toString().isEmpty()) {

                                    ((MainActivity) (getActivity())).addNewList(items, store.getText().toString());
                                    Toast message_new = Toast.makeText(getContext(), "List Added!", Toast.LENGTH_SHORT);
                                    message_new.show();
                                    items.clear();
                                    items.add(sample);
                                    CustomAdapter myAdapter2 = new CustomAdapter(getContext(), R.layout.layout_listviewer, items);
                                    listed.setAdapter(myAdapter2);
                                    ((MainActivity)(getActivity())).updateFragment();
                                    ((MainActivity)(getActivity())).saveData();
                                } else {
                                    Toast message_new = Toast.makeText(getContext(), "Enter List Name", Toast.LENGTH_SHORT);
                                    message_new.show();
                                }

                            }
                        });

                    mBuilder.setView(mView);
                    AlertDialog dialog = mBuilder.create();
                    dialog.show();
                }
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                intent.setType("image/*");
                startActivityForResult(intent, 1);
            }
        });

        return view;
    }

    public class CustomAdapter extends ArrayAdapter<Product> {
        ArrayList<Product> list;
        Context mainContext;

        public CustomAdapter(Context context, int resource, ArrayList<Product> objects) {
            super(context, resource, objects);
            mainContext = context;
            list = objects;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater)mainContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            View layoutView = inflater.inflate(R.layout.layout_listviewer,null);
            TextView tv_name = (TextView)layoutView.findViewById(R.id.textView_listName);
            TextView tv_quant = (TextView)layoutView.findViewById(R.id.textView_listQuantity);
            TextView tv_unit = (TextView)layoutView.findViewById(R.id.textView_listUnits);
            TextView tv_aisle = (TextView)layoutView.findViewById(R.id.textView_listAisleName);
            TextView tv_aisleNum = (TextView)layoutView.findViewById(R.id.textView_listAisleNum);
            TextView tv_priority = (TextView)layoutView.findViewById(R.id.textView_listPriority);
            TextView tv_calories = (TextView)layoutView.findViewById(R.id.textView_listCalories);
            TextView tv_price = (TextView)layoutView.findViewById(R.id.textView_listPrice);
            ImageView imageView = (ImageView)layoutView.findViewById(R.id.imageView_listImage);
            ImageButton removeFromList = (ImageButton)layoutView.findViewById(R.id.imageButton_remove);

            tv_name.setText(list.get(position).getName());

            if(Integer.parseInt(list.get(position).getQuantity().toString()) != 1)
                tv_quant.setText(list.get(position).getQuantity().toString());
            else tv_quant.setText("");

            if(list.get(position).getUnit().toString().equals("Units"))
                tv_unit.setText("");
            else tv_unit.setText(list.get(position).getUnit());

            if(list.get(position).getAisleName().toString().equals("Aisle Name"))
                tv_aisle.setText("");
            else tv_aisle.setText(list.get(position).getAisleName());

            if(Integer.parseInt(list.get(position).getAisleNum().toString()) != 1)
                tv_aisleNum.setText(list.get(position).getAisleNum().toString());
            else tv_aisleNum.setText("");

            tv_priority.setText(list.get(position).getPriority().toString());

            if(Integer.parseInt(list.get(position).getCalories().toString()) != 0)
                tv_calories.setText(list.get(position).getCalories().toString()+" calories");
            else tv_calories.setText("");

            if(list.get(position).getPrice() != 0.0)
                tv_price.setText("$"+String.valueOf(list.get(position).getPrice()));
            else tv_price.setText("");

            switch(position){
                default: imageView.setImageBitmap(retrievedImage); //Change this
            }

            removeFromList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(v.getId() == R.id.imageButton_remove){
                        items.remove(list.get(position));
                        notifyDataSetChanged();
                    }
                }
            });

            return layoutView;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }
        if (requestCode == 1) {
            final Bundle extras = data.getExtras();
            if (extras != null) {
                Uri iUri = data.getData();
                try {
                    Bitmap picture = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(),iUri);
                    retrievedImage=picture;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}